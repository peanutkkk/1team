import React from 'react';
import '../css/Footer_csb.css'; // CSS 파일을 import합니다.

function Footer_csb() {
    return (
        <footer className="footer">
                    <h4>정부24</h4>
                    <p>정부24는 대한민국의 공공서비스를 제공하는 포털 사이트입니다.</p>
                    이메일: csb0012@naver.com<br/>
                    전화: 123-456-7890
            <div className="footer-bottom">
                <p>&copy; 2024 정부24. All Rights Reserved.</p>
            </div>
        </footer>
    );
}

export default Footer_csb;
