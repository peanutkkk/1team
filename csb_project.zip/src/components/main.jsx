import React, { useState } from 'react';
import '../css/Main.css'; // CSS 파일을 import합니다.

const services = Array.from({ length: 7 }, (_, index) => `서비스 ${index + 1}`); // 8개의 서비스 항목을 생성합니다.

function Main() {
    const [currentIndex, setCurrentIndex] = useState(0); // 현재 보여주는 서비스 박스의 인덱스를 관리합니다.

    const handlePrev = () => {
        if (currentIndex > 0) {
            setCurrentIndex(currentIndex - 4); // 이전 버튼 클릭 시 인덱스를 감소시킵니다.
        }
    };

    const handleNext = () => {
        if (currentIndex < services.length - 4) { // 4개의 박스가 화면에 보이는 경우
            setCurrentIndex(currentIndex + 4); // 다음 버튼 클릭 시 인덱스를 증가시킵니다.
        }
    };

    return (
        <div className="container">
            <h1>대한민국 정부24</h1>
            <div className="video-wrapper">
                <iframe 
                    src="https://www.youtube.com/embed/lqLqrFU2wb8" 
                    title="YouTube video player" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowFullScreen>
                </iframe>
            </div>
            <div className="services-wrapper">
                <div className="services-container" style={{ transform: `translateX(-${currentIndex * 25}%)` }}>
                    {services.map((service, index) => (
                        <div key={index} className="service-box">
                            {service}
                        </div>
                    ))}
                </div>
                <div className="nav-buttons">
                    <button onClick={handlePrev}>&lt; </button> {/* 이전 버튼 */}
                    <button onClick={handleNext}> &gt;</button> {/* 다음 버튼 */}
                </div>
            </div>
        </div>
    );
}

export default Main;
