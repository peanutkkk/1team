import React from 'react';
import '../css/about.css';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';

function About() {
    return (
        <div className='aboutWrapper'>
            <h2>
            <span>J</span>
            <span>I</span>
            <span >H</span>
            <span >O</span>
            <span>N</span>
            <span>G</span>
            </h2>
            <p className='about'>기업 소개
            <div className='aboutDetail'>
                <p>경영이념</p>
                <p>사업소개</p>
                <p>연혁</p>
            </div>
            </p>
            <p className='franc'>대리점 관련</p>
            <p className='help'>고객 지원</p>
        <div className='firstFurniture'><img src="../images/furniture1.jpg" alt="firstImage" style={{width:'1000px'}}/>
            </div>
            <span className='introduction'>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Delectus eaque magnam accusamus doloribus expedita laboriosam nesciunt repudiandae, ab iure saepe cum, quasi quo. Voluptatum repellat ullam tenetur totam animi. Expedita.</span>
        </div>
        
    );
}

export default About;