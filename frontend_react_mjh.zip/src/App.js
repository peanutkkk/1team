import React from 'react';
import {BrowserRouter as Router, Route } from 'react-router-dom';
import Home_mjh from './components/Home_mjh';
import About_mjh from './components/About_mjh';


function App() {
  return (
    <div>
      <Router>
        <Route path="/mjh" component={Home_mjh} exact={true} />  
        <Route path="/about_mjh" component={About_mjh} />  
      </Router>      
    </div>
  );
}

export default App;