import React from 'react';
import '../css/about_mjh.css';
import AOS from 'aos';
import 'aos/dist/aos.css';

function About_mjh() {
    return (
        <div className='aboutWrapper'>
            <h2>
                <span>A</span>
                <span>B</span>
                <span>C</span>
                <span>D</span>
                <span>E</span>
                <span>F</span>
            </h2>
                <p className='about'>기업 소개
            <div className='aboutDetail'>
                <p>경영이념</p>
                <p>사업소개</p>
                <p>연혁</p>
            </div>
                </p>
                <p className='franc'>대리점 관련</p>
                <p className='help'>고객 지원</p>
        <div className='container'><img className='firstImage' src="../images/furniture1.jpg" alt="firstImage" style={{width:'1000px'}}/>
            </div>
            <p  className='introduction' >
                <h4>회사 소개</h4>             
                가구를 사랑하고, 집을 아름답게 만드는 것을 신념으로 하는 가구 전문 온라인 쇼핑몰입니다. <br /> 고객 여러분의 집에서 가장 중요한 부분은 무엇인가요? <br />
                우리는 그 질문에 답하기 위해 노력하고 있습니다. <br /> 우리는 당신의 공간을 더 아늑하고 편안하게 만들기 위해 다양한 스타일과 기능성을 갖춘 가구를 제공합니다.
                <br /><br />

                고객이 사랑하는 집을 만드는 데 필요한 모든 것을 제공하는 것입니다. 각 제품은 품질과 디자인에 두각을<br /> 나타내며, 고객이 원하는 스타일과 예산에 맞게 선택할 수 있도록 다양성을 강조합니다. <br /> 우리는 당신의 공간을 더 나은 곳으로 만드는 데 자부심을 가지고 있습니다. <br />

                우리는 고객 만족을 최우선으로 생각합니다. <br /><br /> 우리는 항상 고객의 요구를 이해하고, 진심으로 상담해 드리며, 최상의 서비스를 제공하기 위해 노력합니다. <br />
                또한, 지속 가능성과 윤리적인 생산을 중시하여, 환경과 사회에 긍정적인 영향을 미치기 위해 노력합니다. <br /> 우리의 제품은 품질과 안정성을 바탕으로 오랜 시간 동안 사용할 수 있도록 설계되었습니다. <br /><br />

                우리는 편리하고 안전한 온라인 쇼핑 경험을 제공합니다. 고객 여러분이 쉽고 효율적으로 제품을 선택하고  <br /> 구매할 수 있도록 도와드리며, 안전한 배송과 설치 서비스를 제공합니다. <br /> 고객의 만족을 위해 최선을 다하고, 모든 과정에서 최상의 경험을 제공하는 것을 약속드립니다. <br /> 

                <br />우리는 고객 여러분의 가정을 더 아름답게 만들기 위해 여기 있습니다. <br /> 함께 훌륭한 공간을 만들어가는 여정에 참여해 주셔서 감사합니다.</p>
            <img className='secondImage'  src="../images/sofa.jpg" alt="sofa"  />
            <img className='thirdImage'  src="../images/furniture2.jpg" alt="furniture2" />

</div>
    );
}

export default About_mjh;