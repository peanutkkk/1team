import React from 'react';
import '../css/home_mjh.css';
import 'animate.css';

function Home_mjh() {
    return (
        <div className='wrapper'>
            <h1 >
            <a href="/about">회사 소개</a>
            </h1>
            <div className='home_video'>
                <video autoPlay muted loop><source src="videos/main.mp4" type="video/mp4" /></video>
            </div>

        </div>
    );
}

export default Home_mjh;