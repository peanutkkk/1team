// 패키지 선언
package com.springboot.react.config;

// 필요한 Java 및 Spring 관련 라이브러리를 가져옴
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// Spring Boot의 웹 MVC 설정을 구성하기 위한 클래스 선언
// Configuration 어노테이션을 사용하여 스프링 빈으로 등록
@Configuration
public class WebConfig implements WebMvcConfigurer {

    // CORS(Cross-Origin Resource Sharing) 설정을 위한 메서드 오버라이드
    // CORS는 추가 보안을 위해 서로 다른 출처의 리소스 요청을 허용하거나 제한
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // 모든 경로("/**")에 대해 CORS 설정
        registry.addMapping("/**")
                // 허용된 출처 설정
                // 실제 사용 환경의 IP 주소와 개발 중인 로컬 환경의 주소를 예시로 설정
        		.allowedOrigins("http://192.168.10.200:3000", "http://localhost:3000")
                // 허용된 HTTP 메서드 설정
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                // 허용된 헤더 설정, "*"는 모든 헤더를 허용함을 의미
                .allowedHeaders("*")
                // 쿠키를 포함한 요청을 허용할지 설정
                .allowCredentials(true);
    }
    
    // 정적 리소스 핸들링을 위한 설정 메서드 오버라이드
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // "/react_images/**" 경로로 요청되는 리소스에 대한 처리 설정
        registry.addResourceHandler("/react_images/**")
                // 실제 파일 시스템의 경로와 매핑
                // 이 경로에 저장된 리소스 파일들을 웹에서 접근 가능하도록 설정
                .addResourceLocations("file:///C:/react_images/");
        //[중요 3단계]
        registry.addResourceHandler("/downloadFile/**")
        		.addResourceLocations("file:///C:/react_images/");
        
    }
}
