// 패키지 선언부, 해당 클래스가 속한 패키지 경로를 명시
package com.springboot.react.controller;

// 필요한 Java 및 Spring 관련 라이브러리 및 모듈을 가져옴
import com.springboot.react.entity.Member;
import com.springboot.react.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Optional;

// 클래스에 RestController 어노테이션을 사용하여 HTTP 요청을 처리하는 컨트롤러임을 선언
@RestController
// 클래스 레벨에서 기본 URL 경로를 설정
@RequestMapping("/api/members")
public class MemberController {

    // MemberService 타입의 객체를 자동으로 주입받음
    @Autowired
    private MemberService memberService;

    // 이미지 파일을 저장할 기본 경로 설정
    private final Path rootLocation = Paths.get("C:/react_images");

    // 이미지 파일 업로드를 처리하는 메소드
    @PostMapping("/upload")
    public ResponseEntity<?> uploadImage(@RequestParam("image") MultipartFile file, @RequestParam("member") String memberStr) throws IOException {
        // JSON 문자열을 객체로 변환하기 위해 ObjectMapper 인스턴스 생성
        ObjectMapper objectMapper = new ObjectMapper();
        // 전달받은 JSON 문자열을 Member 객체로 변환
        Member member = objectMapper.readValue(memberStr, Member.class);

        // 파일 저장 로직
        String fileName = file.getOriginalFilename(); // 업로드된 파일의 원본 이름을 가져옴
        Files.copy(file.getInputStream(), this.rootLocation.resolve(fileName), StandardCopyOption.REPLACE_EXISTING); // 파일을 지정된 경로에 저장

        // 저장된 파일의 다운로드 URI 생성
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(fileName)
                .toUriString();
        member.setImagePath(fileDownloadUri); // Member 객체의 이미지 경로 속성 설정

        // 회원 정보 저장
        Member savedMember = memberService.saveMember(member);

        // 클라이언트에 응답 반환, 회원 정보 저장 성공 메시지 전달
  //      return ResponseEntity.ok("회원 가입 정보가 등록되었습니다. ID: " + savedMember.getMemberNumber());
        return ResponseEntity.ok(savedMember);
    }
  //  }
    
    // 로그인 요청을 처리하는 메소드
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Member loginRequest) {
        // 로그인 시도하는 사용자의 ID로 기존 회원 조회
        Optional<Member> foundMember = memberService.findByMemberId(loginRequest.getMemberId());

        // 해당 ID의 회원이 존재하지 않을 경우
        if (!foundMember.isPresent()) {
            return ResponseEntity.badRequest().body("로그인 아이디가 잘못 되었습니다!");
        }

        // 조회된 회원 정보
        Member member = foundMember.get();
        // 비밀번호 일치 여부 확인
        if (!member.getMemberPassword().equals(loginRequest.getMemberPassword())) {
            return ResponseEntity.badRequest().body("패스워드가 잘못 되었습니다!");
        }

        return ResponseEntity.ok(member); //로그인 성공 시 회원 정보를 반환
    }
        
        // 로그인 성공 처리, 실제 운영 환경에서는 추가적인 인증 토큰 발급 등의 작업이 필요
  //      return ResponseEntity.ok("로그인이 성공되었습니다.");
  //  }
}
