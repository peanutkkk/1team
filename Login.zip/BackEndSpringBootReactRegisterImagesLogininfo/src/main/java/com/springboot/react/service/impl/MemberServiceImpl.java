// 패키지 선언
package com.springboot.react.service.impl;

// 필요한 클래스들을 임포트
import com.springboot.react.entity.Member;
import com.springboot.react.repository.MemberRepository;
import com.springboot.react.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

// 이 클래스를 스프링 서비스 컴포넌트로 등록
@Service
public class MemberServiceImpl implements MemberService {

    // MemberRepository 인터페이스에 대한 의존성 주입
    private final MemberRepository memberRepository;

    // 생성자를 통한 의존성 주입, Autowired 어노테이션으로 스프링이 자동으로 주입
    @Autowired
    public MemberServiceImpl(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    // 회원 정보를 저장하는 메소드, 트랜잭셔널 어노테이션을 사용하여 데이터 일관성과 무결성 보장
    @Override
    @Transactional
    public Member saveMember(Member member) {
        // repository의 save 메서드를 호출하여 Member 객체를 데이터베이스에 저장
        return memberRepository.save(member); // 회원 가입 등록
    }

    // 주어진 memberId로 회원을 찾아서 반환하는 메소드
    @Override
    public Optional<Member> findByMemberId(String memberId) {
        // repository의 findByMemberId 메서드를 호출하여 memberId에 해당하는 Member 객체를 검색
        return memberRepository.findByMemberId(memberId); // 구현 추가
    }
}
