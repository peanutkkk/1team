// 패키지 선언
package com.springboot.react.entity;

// JPA(Java Persistence API) 관련 어노테이션 및 기타 필요한 Java 라이브러리를 임포트
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

// Lombok 라이브러리를 사용하여 Getter, Setter, 생성자 등을 자동으로 생성
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// 클래스를 데이터베이스 테이블에 매핑
@Entity
// 데이터베이스 내의 테이블 이름을 'members'로 지정
@Table(name = "members")
// Lombok 어노테이션으로 게터와 세터 메서드 자동 생성
@Getter
@Setter
// 파라미터가 없는 기본 생성자 자동 생성
@NoArgsConstructor
// 모든 필드를 포함하는 생성자 자동 생성
@AllArgsConstructor
public class Member {
    
    // 고유번호를 위한 필드, 데이터베이스의 기본 키로 사용
    @Id
    // 값 생성을 위해 시퀀스를 사용, 시퀀스 생성기를 정의
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "member_seq")
    @SequenceGenerator(name = "member_seq", sequenceName = "MEMBER_SEQ", allocationSize = 1)
    private Long memberNumber;
    
    // 회원 아이디, NULL을 허용하지 않음
    @Column(nullable = false)
    private String memberId;

    // 회원 비밀번호, NULL을 허용하지 않음
    @Column(nullable = false)
    private String memberPassword;

    // 회원 이름, NULL을 허용하지 않음
    @Column(nullable = false)
    private String memberName;
    
    // 이미지 파일의 저장 경로, NULL 허용
    @Column(nullable = true)
    private String imagePath; // 추가 설명: 회원 프로필 이미지 경로, 이미지가 없을 경우 NULL 가능
    
}
