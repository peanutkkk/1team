// 패키지 선언
package com.springboot.react.repository;

// 필요한 Java 및 Spring 관련 라이브러리를 가져옴
import com.springboot.react.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

// Member 엔티티에 대한 리포지토리 인터페이스 정의
// JpaRepository를 상속받음으로써 기본적인 데이터베이스 연산을 자동으로 구현
public interface MemberRepository extends JpaRepository<Member, Long> {
    // 사용자 정의 쿼리 메서드 추가
    // 특정 회원 아이디(memberId)를 사용하여 회원 정보를 조회
    // 반환 값은 Optional로, 회원 정보가 존재하지 않을 경우를 처리하기 위해 Optional<Member> 반환
    Optional<Member> findByMemberId(String memberId); // 메소드 추가
}
