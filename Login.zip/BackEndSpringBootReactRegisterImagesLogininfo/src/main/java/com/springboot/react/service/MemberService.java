// 패키지 선언
package com.springboot.react.service;

// 필요한 클래스를 임포트
import com.springboot.react.entity.Member;
import java.util.Optional;

// 회원 관련 서비스를 위한 인터페이스 정의
public interface MemberService {
    // 회원 정보를 저장하고, 저장된 회원 정보를 반환하는 메서드
    // 주로 회원 가입 시 사용
    Member saveMember(Member member); // 회원 가입 메서드
    
    // 주어진 memberId로 회원을 찾아 Optional 객체로 반환하는 메서드
    // memberId가 데이터베이스에 존재하지 않을 경우, Optional.empty() 반환
    // 이 메서드는 회원 로그인 또는 정보 조회 시에 유용하게 사용됨
    Optional<Member> findByMemberId(String memberId); // 메소드 추가
}
