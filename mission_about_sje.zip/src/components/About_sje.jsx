import React from 'react';
import Container from 'react-bootstrap/Container'
import '../css/about_sje.css';
import { Link } from 'react-router-dom';

function About_sje() {

    return (
        <div id='about-wrapper-sje'>
            <Container>
                <div className='box-1'></div>
                <Link to='/'>
                    <img className='logo' src="images/logo_sje.svg" alt="logo" />
                </Link>
                <div className='title'>
                    <h1>About Colons:D</h1>
                    <p className='title-p'>당신의 모든 여행을 함께하는</p>
                    <Link to='/-'>
                    <div className='about-title-imgbox'>
                        <img src="images/about01_sje.jpg" alt="title" />
                    </div>
                    <p className='title-a'>바로가기 &#62;&#62;</p>
                    </Link>
                </div>
                <div className='content-1'>
                    <h1>History</h1>
                    <div className='history-title'>
                        <p className='history-title-year'>2015</p>
                            <p className='history-title-content'>
                                Colons:D 창립</p>
                        <p className='history-title-year'>2017</p>
                            <p className='history-title-content'>
                                모바일 서비스 지원</p>
                        <p className='history-title-year'>2018</p>
                            <p className='history-title-content'>
                                중국 글로벌 서비스 런칭</p>
                        <p className='history-title-year'>2020</p>
                            <p className='history-title-content'>
                                일본 글로벌 서비스 런칭</p>
                        <p className='history-title-year'>2021</p>
                            <p className='history-title-content'>
                                미국 글로벌 서비스 런칭</p>
                        <p className='history-title-year'>2022</p>
                            <p className='history-title-content'>
                                패키지 여행 상품 출시</p>
                        <p className='history-title-year'>2024</p>
                            <p className='history-title-content'>
                                랜선투어 상품 출시</p>
                    </div>
                </div>
                <div className='content-2'>
                    <h1>News</h1>
                    <hr />
                    <a href="https://news.google.com/home?hl=ko&gl=KR&ceid=KR:ko">
                    [단독] Colons:D 대표 사퇴 소식, 비난의 목소리...</a><br />
                    <a href="https://news.google.com/home?hl=ko&gl=KR&ceid=KR:ko">
                    [속보] Kakao 여행 사업에 뛰어들어... 협력 업체들은?</a><br />
                    <a href="https://news.google.com/home?hl=ko&gl=KR&ceid=KR:ko">
                    대형 여행 업체 Colons:D, 글로벌 서비스 런칭</a><br />
                    <a href="https://news.google.com/home?hl=ko&gl=KR&ceid=KR:ko">
                    [단독] Colons:D, 사용자수 10만명 돌파...</a>
                    <hr />
                </div>
                <br />
                <br />
                <br />
            </Container>
        </div>
    );
}

export default About_sje;