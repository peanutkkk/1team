import React from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css'; 

function Landing() {
    return (
        <div>
            <Link to='/about_sje'>회사소개</Link>
        </div>
    );
}

export default Landing;