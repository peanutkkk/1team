import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import About_sje from './components/About_sje';
import Landing from './components/Landing';

function App() {
  return (
    <div>
      <Router>
        <Route path='/' component={Landing} exact={true} />
        <Route path='/about_sje' component={About_sje} />
      </Router>
    </div>
  );
}

export default App;