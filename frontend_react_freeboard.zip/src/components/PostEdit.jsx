import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useHistory } from 'react-router-dom';
import '../css/PostEdit.css'; // PostEdit의 CSS 파일

function PostEdit() {
    const [post, setPost] = useState({ boardTitle: '', boardContents: '', boardWriter: '' });
    const { boardNumber } = useParams();
    const history = useHistory();

    useEffect(() => {
        const fetchPost = async () => {
            try {
                const response = await axios.get(`http://localhost:9008/api/posts/${boardNumber}`);
                setPost(response.data);
            } catch (error) {
                console.log(error);
                alert('에러가 발생했습니다!');
            }
        };
        fetchPost();
    }, [boardNumber]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setPost(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleUpdate = async () => {
        try {
            const { boardWriter, ...updateData } = post;
            await axios.put(`http://localhost:9008/api/posts/${boardNumber}`, updateData);
            alert('게시글이 수정되었습니다!');
            history.push('/');
        } catch (error) {
            console.error("게시글 수정 실패", error);
        }
    };

    const handleCancel = () => {
        history.goBack();
    };

    const goToPostList = () => {
        history.push('/');
    };

    return (
        <div className="container">
            <h2>게시글 수정</h2>
            <form>
                <div className="form-group">
                    <label>제목</label>
                    <input type='text' name="boardTitle" value={post.boardTitle || ''} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>내용</label>
                    <textarea name='boardContents' value={post.boardContents || ''} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>작성자 : {post.boardWriter}</label>
                </div>
                <div className="button-group">
                    <button className="editBtn" type='button' onClick={handleUpdate}>수정 처리</button>
                    <button className="listBtn" type='button' onClick={goToPostList}>글목록으로 이동</button>
                    <button className="deleteBtn" type='button' onClick={handleCancel}>수정 취소</button>
                </div>
            </form>
        </div>
    );
}

export default PostEdit;
