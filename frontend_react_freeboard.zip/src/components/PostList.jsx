import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useHistory } from 'react-router-dom';
import Pagination from 'react-js-pagination';
import '../css/PostList.css'; // 커스텀 CSS 파일

function PostList() {
    const [posts, setPosts] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [postsPerPage] = useState(5);
    const history = useHistory();

    // 백엔드에서 게시글 목록을 조회하는 함수
    const fetchPosts = async () => {
        try {
            console.log('게시글 목록 조회 요청 시작');
            const response = await axios.get('http://192.168.10.19:9008/api/posts');
            console.log('응답 데이터:', response.data);
            // 서버로부터 받은 데이터를 직접 상태에 저장
            setPosts(response.data);
        } catch (error) {
            console.error("게시글 목록 조회 에러", error);
            alert("게시글 목록 조회 실패!");
        }
    };

    // 게시글을 삭제하는 함수입니다.
    const handleDelete = async (boardNumber) => {
        if (window.confirm("게시글을 삭제하시겠습니까?")) {
            try {
                await axios.delete(`http://localhost:9008/api/posts/${boardNumber}`);
                alert('게시글이 삭제되었습니다.');
                fetchPosts(); // 삭제 처리 후에 게시글 목록을 다시 조회합니다.
            } catch (error) {
                console.error('게시글 삭제 실패', error);
                alert('게시글 삭제에 실패했습니다!');
            }
        }
    };

    useEffect(() => {
        fetchPosts();
    }, []);

    // 현재 페이지에 해당하는 게시글을 계산합니다.
    const indexOfLastPost = currentPage * postsPerPage;
    const indexOfFirstPost = indexOfLastPost - postsPerPage;
    const currentPosts = posts.slice(indexOfFirstPost, indexOfLastPost);

    // 페이지 번호를 변경하는 함수입니다.
    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    return (
        <div>
            <h2>자유 게시판</h2>
            <hr />
            <ul className='register'>
            <Link to='/create'>게시글 등록으로 이동</Link>
            </ul>
            <ul class="letter">
                {currentPosts.map(post => (
                    <li key={post.boardNumber}>
                        <Link to={`/posts/${post.boardNumber}`}>
                            <h3>{post.boardTitle}</h3>
                        </Link>
                        작성자 : {post.boardWriter}
                    </li>
                ))}
            </ul>
            <Pagination
                activePage={currentPage}
                itemsCountPerPage={postsPerPage}
                totalItemsCount={posts.length}
                pageRangeDisplayed={5}
                onChange={paginate}
                itemClass="page-item"
                linkClass="page-link"
            />
        </div>
    );
}

export default PostList;
