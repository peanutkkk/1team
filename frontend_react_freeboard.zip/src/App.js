// rsf
import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import PostList from './components/PostList';
import PostDetail from './components/PostDetail';
import PostEdit from './components/PostEdit';
import CreatePost from './components/CreatePost';

function App() {
  return (
    <div>
      <Router>
        <Route path="/" component={PostList} exact={true} />
        <Route path="/posts/:boardNumber" component={PostDetail} />
        <Route path="/edit/:boardNumber" component={PostEdit} />
        <Route path="/create" component={CreatePost} exact={true} />
      </Router>
    </div>
  );
}

export default App;
