import React from 'react';
import '../css/footer.css';
import { Link } from 'react-router-dom';
import { Container } from 'react-bootstrap';

function Footer() {
    return (
        <div id='footer'>
            <Container>
                <div className='footer-link'>
                    <Link to="/이용약관">이용약관</Link>
                    <span>｜</span>
                    <Link to="/개인정보 처리방침">개인정보 처리방침</Link>
                    <span>｜</span>
                    <Link to="/이용안내">이용안내</Link>
                    <span>｜</span>
                    <Link to="/고객지원센터">고객지원센터</Link>
                </div>
                <div className="separator"></div> {/* 흰색 선 추가 */}
                <div className='footer-copyright'>
                    <span>© 2024 Riot Games, Inc. All Rights Reserved.</span>
                    <br />
                </div>
            </Container>
        </div>
    );
}

export default Footer;
