import React from 'react';
import '../css/main.css';
import 'bootstrap/dist/css/bootstrap.css'; 
import Container from 'react-bootstrap/Container';
import Reactplayer from 'react-player';


function Main() {
    return (
        <div>
             <Container>
                <div className='player'>
                <Reactplayer
                    // 컴포넌트에서 유튜브 동영상 위치 지정
                    url='https://youtu.be/ZHhqwBwmRkI?si=CCdWzWdPDnCroDa4'
                    // 자동 실행 설정(true)
                    playing={true}
                    // 음소거 설정(true)
                    // 참고로, 자동 재생 설정은 playing과 muted를 true로 설정해야 합니다.
                    muted={true}
                    // 플레이어 컨트롤 노출 설정(true)
                    controls={true}
                    // 반복 재생 설정(true)
                    loop={true}
                />
                </div>
            </Container> 



            <h1>라이엇 게임즈는 세계에서 가장 플레이어 중심적인</h1><h1>게임 회사가 되기 위해 노력하고 있습니다</h1>
            <br />
            <h3>
                라이엇 게임즈는 플레이어 입장에서 더 나은 게임과 경험을 만들고자 2006년에 설립되었습니다. 2009년 출시한 데뷔작 리그 오브 레전드는 세계에서 가장 많이 플레이하는 PC 게임의 반열에 올랐습니다. 이후 해를 거듭하며 발로란트, 전략적 팀 전투, 레전드 오브 룬테라, 리그 오브 레전드: 와일드 리프트 등을 출시했습니다. 라이엇의 게임은 세계에서 손꼽을 만큼 인지도가 높은 e스포츠 종목이며 매년 수백만 명의 팬이 보는 리그 오브 레전드 월드 챔피언십, 발로란트 챔피언스 같은 대회가 한 해의 대미를 장식합니다. 그 밖에 음악과 코믹 도서, 보드게임, 에미상을 받은 애니메이션 시리즈 아케인 등 다양한 프로젝트로 라이엇의 IP를 확장했습니다.
            </h3>
        </div>
    );
}

export default Main;
