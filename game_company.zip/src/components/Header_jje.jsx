import { Link } from 'react-router-dom';
import React, { useState } from 'react';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import "../css/header_jje.css";

function Header_jje() {
    const [expanded, setExpanded] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');

    const handleToggle = () => {
        setExpanded(!expanded);
    };

    const handleClose = () => {
        setExpanded(false);
    };

    const handleSearchChange = (event) => {
        setSearchQuery(event.target.value);
    };

    const handleSearchSubmit = (event) => {
        event.preventDefault();
        // 검색 기능 구현
        console.log('검색어:', searchQuery);
        // 검색 결과 페이지로 이동하거나 검색 결과를 표시하는 로직을 추가
    };

    return (
        <>
            <Navbar expand="lg" id="navbars" expanded={expanded}>
                <Container>
                    <Navbar.Brand as={Link} to="/main" onClick={handleClose} className='nav-title'>
                        <img src="../icons/riot_logo_.png" alt="Riot" />
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" onClick={handleToggle} />
                    <Navbar.Collapse id="basic-navbar-nav" className='justify-content-between'>
                        <Nav className="mx-auto">
                            <Nav.Link as={Link} to="/About_jje" onClick={handleClose} className="nav-item">회사 소개</Nav.Link>
                            <Nav.Link as={Link} to="/엔터테인먼트" onClick={handleClose} className="nav-item">엔터테인먼트</Nav.Link>
                            <Nav.Link as={Link} to="/소식" onClick={handleClose} className="nav-item">소식</Nav.Link>
                            <NavDropdown title="RIOT FORGE" id="basic-nav-dropdown" className='nav-dropdown'>
                                <NavDropdown.Item as={Link} to="/시간교차" onClick={handleClose}>시간/교차</NavDropdown.Item>
                                <NavDropdown.Item as={Link} to="/마법공학" onClick={handleClose}>마법공학 아수라장</NavDropdown.Item>
                                <NavDropdown.Item as={Link} to="/마력척결관" onClick={handleClose}>마력 척결관</NavDropdown.Item>
                                <NavDropdown.Item as={Link} to="/몰락한왕" onClick={handleClose}>몰락한 왕</NavDropdown.Item>
                                <NavDropdown.Item as={Link} to="/누누의노래" onClick={handleClose}>누누의 노래</NavDropdown.Item>
                                <NavDropdown.Item as={Link} to="/riotforge" onClick={handleClose}>RIOT FORGE의 게임 </NavDropdown.Item>
                            </NavDropdown>
                            <NavDropdown title="게임" id="basic-nav-dropdown" className='nav-dropdown'>
                                <NavDropdown.Item as={Link} to="/LOL" onClick={handleClose}>리그 오브 레전드</NavDropdown.Item>
                                <NavDropdown.Item as={Link} to="/VAL" onClick={handleClose}>발로란트</NavDropdown.Item>
                                <NavDropdown.Item as={Link} to="/TFT" onClick={handleClose}>TFT</NavDropdown.Item>
                                <NavDropdown.Item as={Link} to="/RUNE" onClick={handleClose}>레전드 오브 룬테라</NavDropdown.Item>
                                <NavDropdown.Item as={Link} to="/LOLWR" onClick={handleClose}>리그 오브 레전드:와일드 리프트</NavDropdown.Item>
                            </NavDropdown>
                            <NavDropdown title="e-스포츠" id="basic-nav-dropdown" className='nav-dropdown'>
                                <NavDropdown.Item as={Link} to="/리그오브레전드e스포츠" onClick={handleClose}>리그 오브 레전드 e 스포츠</NavDropdown.Item>
                                <NavDropdown.Item as={Link} to="/발로란트e스포츠" onClick={handleClose}>발로란트 e 스포츠</NavDropdown.Item>
                            </NavDropdown>
                        </Nav>
                        <div className='navbars_icon'>
                            <form onSubmit={handleSearchSubmit} className="search-form">
                                <input 
                                    type="text" 
                                    value={searchQuery} 
                                    onChange={handleSearchChange} 
                                    placeholder="검색어를 입력하세요" 
                                    className='search-input'
                                />
                                <button type="submit" className='search-button'>
                                    <img src="../icons/search_icon_jje.svg" alt="search" className='search-icon'/>
                                </button>
                            </form>
                            <Link to="/로그인" onClick={handleClose}>
                                <img src="../icons/user_icon_jje.svg" alt="login" className='icon-white'/>
                            </Link>
                        </div>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </>
    );
}

export default Header_jje;
