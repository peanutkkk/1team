import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import main from './components/Main';
import Header from './components/Header';
import Footer from './components/Footer';

const App = () => (
  <div className='app app-container'>
  <div className="navbar">
      
      </div>
  <Router>
<Header />
<Switch>
    <Route path="/회사소개" component={main}></Route>


</Switch>
        <Footer />
      </Router>
    </div>
  
  );
export default App;