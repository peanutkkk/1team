import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import About_jje from './components/About_jje';

const App = () => (
  <div className='app app-container'>
  <div className="navbar">
      
      </div>
  <Router>
<Header />
<Switch>
    <Route path="/About_jje" component={About_jje}></Route>


</Switch>
        <Footer />
      </Router>
    </div>
  
  );
export default App;