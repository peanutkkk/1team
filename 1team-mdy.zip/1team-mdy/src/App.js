import React from 'react';
import { BrowserRouter as Router, Route, Switch, useLocation } from 'react-router-dom';
// import Main from './components/Main';
import ABOUT_Mdy from './components/ABOUT_Mdy';
// import Home_mjh from './components/Home_mjh';
// import About_mjh from './components/About_mjh';
// import About_sje from './components/About_sje';

// import Router_jje from './components/Router_jje';





function App() {
  return (

    <div className="App">
    
      {/* <div className="container mt-4"></div> */}
      <Switch>
        {/* <Route path="/" component={Main} exact={true} /> */}
        <Route path="/" component={ABOUT_Mdy} />
        {/* <Route path="/mjh" component={Home_mjh}  />  
        <Route path="/about_mjh" component={About_mjh} />  
 	      <Route path='/about_sje' component={About_sje} /> */}
         {/* <Route path="/about_jje" component={About_jje}></Route> */}
	      {/* <Router_jje /> */}

        {/* <Navbar_csb />
        <Route path="/landing_csb" component={LandingPage_csb} />
       
          <Route path="/main_csb" component={Main_csb}/>
          <Route path="/about_csb" component={About_csb} />
          <Route path="/location_csb" component={location_csb} />
          <Route path="/qna_csb" component={Qna_csb} />
          <Footer_csb/> */}
          </Switch>
     
      {/* <Mdy/> */}
    </div>
  );
}





export default App;