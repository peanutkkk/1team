
import React, {useEffect} from "react";
import AOS from "aos";
import "../css/aos.css";
import "../css/mdy.css";





function ABOUT_Mdy() {
   
    
        useEffect (()=>{
            AOS.init({duration:2000});
        }); 

       


    return (
      
        <div className='contents'>
            <div className='locationWrap'>
                <div className='brand-storywrap'>
                    <picture>
                        <div className='picture1'>
                            <span className='conceptPicture'>
                           
                            <img src="images/top.jpg" alt="picture1" />   
                            </span>
                        </div>
                    </picture>    

                        <div className='introduceText'>
                            <div className="pictureD">
                                <p data-aos="fade-left" className='introTit'>agabang   </p>
                                <p className="introDesc">
                                1979년 런칭 이래 지금까지 아가들의 웃음과 꿈을 가꾸는 엄마의 마음을 담은 대한 민국 대표 브랜드입니다.<br/>
                                자연친화적인 편한 소재를 사용, 소프트하고 사랑스러운 칼라와 섬세한 디테일로 트랜디 하면서도 편안한 스타일을 제안합니다.
                                </p>
                            </div>
                         </div>
                         {/* introduceText  */}

                         <div className='picture2'>
                            <span className='conceptPicture2'>
                                <img src="./images/top2.jpg" alt="concept2" />
                            </span>
                        </div>
                        {/* picture2 */}




                   

                </div>
                {/* brandstoryWrap */}
            
               



            </div> 
                {/* locationWrap */}
        </div>
     

    );

}
export default ABOUT_Mdy;
