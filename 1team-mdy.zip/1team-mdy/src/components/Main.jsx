import React from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
import "../css/main.css";

function Main() {
    return (
        <div className='inner'>

            <div className='mLogo'>
                <img src="images/earth1.png" alt="logo"  />
            </div>
           
            <div className='teamTit'>
                [개발1팀]
            </div>
           
           <div className='teamName'>
           <p><Link to ="/about_mdy">문도연</Link></p>
            <br/>
             {/* <Link to ="/mjh">민지홍</Link>
             <Link to ="/about_sje">서정은</Link>
             <Link to ="/about_jje">장정은</Link> */}

            {/* <Link to ="/landing_csb">최승빈</Link> */}
           
            
            </div>

        </div>
    );
}

export default Main;